from __future__ import annotations

import math
import random
from typing import Dict, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchaudio.transforms as T
from pytorch_lightning import LightningModule
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torchmetrics.audio.pesq import PerceptualEvaluationSpeechQuality

from codec import EncodecBatch, EncodecWrapper
from config import (
    baseline_loss_weight,
    confidence_reg_weight,
    decode_encodec_during_training,
    encodec_bandwidth,
    encodec_model_name,
    hybrid_loss_weight,
    inference_mode,
    sampling_rate,
    token_loss_weight,
    use_encodec_branch,
    use_gate_entropy,
    use_hybrid_fusion,
    warmup_baseline_epochs,
)
from utils.dnn import BasicBlock, ResNet, Swish, cal_si_snr


# =========================================================
# HELPERS
# =========================================================

def _match_length(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    """Match x to y along the last dim."""
    if x.shape[-1] == y.shape[-1]:
        return x
    if x.shape[-1] > y.shape[-1]:
        return x[..., : y.shape[-1]]
    reps = math.ceil(y.shape[-1] / max(1, x.shape[-1]))
    x_rep = x.repeat(*([1] * (x.dim() - 1)), reps)
    return x_rep[..., : y.shape[-1]]


# =========================================================
# AUDIO ENCODER / DECODER
# =========================================================

class AudioEncoder(nn.Module):
    def __init__(self, kernel_size=16, out_channels=256):
        super().__init__()
        self.conv1d = nn.Conv1d(
            1,
            out_channels,
            kernel_size=kernel_size,
            stride=kernel_size // 2,
            padding=kernel_size // 2,
            bias=False,
        )

    def forward(self, x):
        return F.relu(self.conv1d(x.unsqueeze(1)))


class AudioDecoder(nn.ConvTranspose1d):
    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        out = super().forward(x)
        return out.squeeze(1)


# =========================================================
# VISUAL FRONTEND
# =========================================================

class VisualFeatNet(nn.Module):
    def __init__(self, relu_type="relu"):
        super().__init__()
        self.frontend_nout = 64
        self.trunk = ResNet(BasicBlock, [1, 1, 1, 1, 1], relu_type=relu_type)
        frontend_relu = {
            "relu": nn.ReLU(True),
            "prelu": nn.PReLU(self.frontend_nout),
            "swish": Swish(),
        }[relu_type]
        self.frontend3D = nn.Sequential(
            nn.Conv3d(
                1,
                self.frontend_nout,
                kernel_size=(5, 7, 7),
                stride=(1, 2, 2),
                padding=(2, 3, 3),
                bias=False,
            ),
            nn.BatchNorm3d(self.frontend_nout),
            frontend_relu,
            nn.MaxPool3d(
                kernel_size=(1, 3, 3),
                stride=(1, 2, 2),
                padding=(0, 1, 1),
            ),
        )
        self.nn_out = nn.Linear(512, 256, bias=False)
        torch.nn.init.xavier_uniform_(self.nn_out.weight)
        self._initialize_weights_randomly()

    def forward(self, x):
        bsz, _, _, _, _ = x.size()
        x = self.frontend3D(x)
        t_new = x.shape[2]
        n_batch, n_channels, s_time, sx, sy = x.shape
        x = x.transpose(1, 2).reshape(n_batch * s_time, n_channels, sx, sy)
        x = self.trunk(x)
        x = x.view(bsz, t_new, x.size(1))
        return torch.relu(self.nn_out(x))

    def _initialize_weights_randomly(self):
        factor = lambda n: math.sqrt(2.0 / float(n))
        for module in self.modules():
            if isinstance(module, (nn.Conv3d, nn.Conv2d, nn.Conv1d)):
                n = np.prod(module.kernel_size) * module.out_channels
                module.weight.data.normal_(0, factor(n))
                if module.bias is not None:
                    module.bias.data.zero_()
            elif isinstance(module, (nn.BatchNorm3d, nn.BatchNorm2d, nn.BatchNorm1d)):
                module.weight.data.fill_(1)
                module.bias.data.zero_()
            elif isinstance(module, nn.Linear):
                n = float(module.weight.data[0].nelement())
                module.weight.data = module.weight.data.normal_(0, factor(n))


# =========================================================
# SEPARATOR  (DPRNN-style blocks)
# =========================================================

class SeparatorBlock(nn.Module):
    def __init__(self, out_channels, hidden_channels, dropout=0.0, bidirectional=False):
        super().__init__()
        hidden_out = hidden_channels * 2 if bidirectional else hidden_channels
        self.intra_rnn = nn.LSTM(out_channels, hidden_channels, 1, batch_first=True,
                                 bidirectional=bidirectional)
        self.inter_rnn = nn.LSTM(out_channels, hidden_channels, 1, batch_first=True,
                                 bidirectional=bidirectional)
        self.intra_norm = nn.GroupNorm(1, out_channels, eps=1e-8)
        self.inter_norm = nn.GroupNorm(1, out_channels, eps=1e-8)
        self.intra_linear = nn.Linear(hidden_out, out_channels)
        self.inter_linear = nn.Linear(hidden_out, out_channels)

    def forward(self, x):
        bsz, channels, ksize, chunks = x.shape

        intra = (
            x.permute(0, 3, 2, 1)
            .contiguous()
            .view(bsz * chunks, ksize, channels)
        )
        intra, _ = self.intra_rnn(intra)
        intra = self.intra_linear(intra.reshape(-1, intra.shape[-1]))
        intra = intra.view(bsz * chunks, ksize, channels)
        intra = (
            intra.view(bsz, chunks, ksize, channels)
            .permute(0, 3, 2, 1)
            .contiguous()
        )
        intra = self.intra_norm(intra) + x

        inter = (
            intra.permute(0, 2, 3, 1)
            .contiguous()
            .view(bsz * ksize, chunks, channels)
        )
        inter, _ = self.inter_rnn(inter)
        inter = self.inter_linear(inter.reshape(-1, inter.shape[-1]))
        inter = inter.view(bsz * ksize, chunks, channels)
        inter = (
            inter.view(bsz, ksize, chunks, channels)
            .permute(0, 3, 1, 2)
            .contiguous()
        )
        return self.inter_norm(inter) + intra


class Separator(nn.Module):
    def __init__(
        self,
        in_channels,
        out_channels,
        hidden_channels,
        dropout=0.3,
        bidirectional=True,
        num_layers=1,
        ksize=200,
    ):
        super().__init__()
        self.ksize = ksize
        self.input_conv = nn.Sequential(
            nn.GroupNorm(1, in_channels, eps=1e-8),
            nn.Conv1d(in_channels, out_channels, 1, bias=False),
        )
        self.separator_blocks = nn.Sequential(
            *[
                SeparatorBlock(
                    out_channels,
                    hidden_channels,
                    dropout=dropout,
                    bidirectional=bidirectional,
                )
                for _ in range(num_layers)
            ]
        )
        self.conv2d = nn.Conv2d(out_channels, out_channels, kernel_size=1)
        self.prelu = nn.PReLU()
        self.output = nn.Sequential(
            nn.Conv1d(out_channels, out_channels, 1), nn.Tanh()
        )
        self.output_gate = nn.Sequential(
            nn.Conv1d(out_channels, out_channels, 1), nn.Sigmoid()
        )
        self.end_conv1x1 = nn.Conv1d(out_channels, 256, 1, bias=False)

    def forward(self, x):
        x = self.input_conv(x)
        x, gap = self._segment(x, self.ksize)
        x = self.separator_blocks(x)
        x = self.prelu(x)
        x = self.conv2d(x)
        bsz, _, ksize, chunks = x.shape
        x = x.view(bsz, -1, ksize, chunks)
        x = self._over_add(x, gap)
        x = self.output(x) * self.output_gate(x)
        x = self.end_conv1x1(x)
        return F.relu(x)

    def _padding(self, inp, ksize):
        bsz, channels, length = inp.shape
        pad = ksize // 2
        gap = ksize - (pad + length % ksize) % ksize
        if gap > 0:
            inp = torch.cat(
                [
                    inp,
                    torch.zeros(
                        bsz, channels, gap, device=inp.device, dtype=inp.dtype
                    ),
                ],
                dim=2,
            )
        edge = torch.zeros(
            bsz, channels, pad, device=inp.device, dtype=inp.dtype
        )
        inp = torch.cat([edge, inp, edge], dim=2)
        return inp, gap

    def _segment(self, inp, ksize):
        bsz, channels, _ = inp.shape
        pad = ksize // 2
        inp, gap = self._padding(inp, ksize)
        inp1 = inp[:, :, :-pad].contiguous().view(bsz, channels, -1, ksize)
        inp2 = inp[:, :, pad:].contiguous().view(bsz, channels, -1, ksize)
        inp = (
            torch.cat([inp1, inp2], dim=3)
            .view(bsz, channels, -1, ksize)
            .transpose(2, 3)
            .contiguous()
        )
        return inp, gap

    def _over_add(self, inp, gap):
        bsz, channels, ksize, chunks = inp.shape
        pad = ksize // 2
        inp = (
            inp.transpose(2, 3)
            .contiguous()
            .view(bsz, channels, -1, ksize * 2)
        )
        inp1 = (
            inp[:, :, :, :ksize]
            .contiguous()
            .view(bsz, channels, -1)[:, :, pad:]
        )
        inp2 = (
            inp[:, :, :, ksize:]
            .contiguous()
            .view(bsz, channels, -1)[:, :, :-pad]
        )
        out = inp1 + inp2
        if gap > 0:
            out = out[:, :, :-gap]
        return out


# =========================================================
# TOKEN BRANCH
# =========================================================

class TokenRateAdapter(nn.Module):
    def __init__(self, in_channels=512, out_channels=384):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Conv1d(in_channels, out_channels, 1),
            nn.GroupNorm(1, out_channels),
            nn.GELU(),
        )

    def forward(self, x: torch.Tensor, target_steps: int) -> torch.Tensor:
        target_steps = max(1, int(target_steps))
        x = self.proj(x)
        return F.adaptive_avg_pool1d(x, target_steps)


class TemporalRefiner(nn.Module):
    def __init__(self, channels=384, num_layers=3):
        super().__init__()
        self.layers = nn.ModuleList()
        for dilation in [1, 2, 4][:num_layers]:
            self.layers.append(
                nn.Sequential(
                    nn.Conv1d(
                        channels,
                        channels,
                        3,
                        padding=dilation,
                        dilation=dilation,
                        groups=channels,
                    ),
                    nn.Conv1d(channels, channels, 1),
                    nn.GELU(),
                    nn.GroupNorm(1, channels),
                )
            )

    def forward(self, x):
        for layer in self.layers:
            x = x + layer(x)
        return x


class CodecTokenHead(nn.Module):
    def __init__(
        self, in_channels=384, hidden_channels=384, n_q=8, vocab_size=1024
    ):
        super().__init__()
        self.n_q = n_q
        self.vocab_size = vocab_size
        self.net = nn.Sequential(
            nn.Conv1d(in_channels, hidden_channels, 1),
            nn.GELU(),
            nn.Conv1d(hidden_channels, hidden_channels, 3, padding=1),
            nn.GELU(),
            nn.Conv1d(hidden_channels, n_q * vocab_size, 1),
        )

    def forward(self, x):
        logits = self.net(x)
        bsz, _, steps = logits.shape
        return logits.view(bsz, self.n_q, self.vocab_size, steps)


class ConfidenceGate(nn.Module):
    def __init__(self, feat_channels=384, hidden=128, use_entropy=True):
        super().__init__()
        in_dim = feat_channels + (2 if use_entropy else 0)
        self.use_entropy = use_entropy
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, 1),
            nn.Sigmoid(),
        )

    def forward(
        self, token_features: torch.Tensor, token_logits: torch.Tensor
    ) -> torch.Tensor:
        pooled = token_features.mean(dim=-1)
        if self.use_entropy:
            probs = torch.softmax(token_logits, dim=2)
            entropy = -(
                probs * torch.log(probs.clamp_min(1e-8))
            ).sum(dim=2)
            stats = torch.stack(
                [entropy.mean(dim=(1, 2)), entropy.std(dim=(1, 2))], dim=-1
            )
            pooled = torch.cat([pooled, stats], dim=-1)
        return self.mlp(pooled)


# =========================================================
# HYBRID MODEL
# =========================================================

class AVSEHybrid(nn.Module):
    def __init__(self, n_q: int, vocab_size: int, token_rate_estimator):
        super().__init__()
        self.audio_encoder = AudioEncoder(kernel_size=16, out_channels=256)
        self.audio_decoder = AudioDecoder(
            in_channels=256,
            out_channels=1,
            kernel_size=16,
            stride=8,
            padding=8,
            bias=False,
        )
        self.visual_encoder = VisualFeatNet()
        self.separator = Separator(
            512, 32, 32, num_layers=1, bidirectional=True, dropout=0.3
        )

        self.token_adapter = TokenRateAdapter(in_channels=512, out_channels=384)
        self.token_refiner = TemporalRefiner(channels=384, num_layers=3)
        self.token_head = CodecTokenHead(
            in_channels=384, hidden_channels=384, n_q=n_q, vocab_size=vocab_size
        )
        self.gate = ConfidenceGate(
            feat_channels=384, hidden=128, use_entropy=use_gate_entropy
        )
        self.token_rate_estimator = token_rate_estimator

    def forward(
        self,
        inputs: Dict[str, torch.Tensor],
        token_steps: Optional[int] = None,
        decode_codec: bool = False,
        codec: Optional[EncodecWrapper] = None,
        codec_meta: Optional[EncodecBatch] = None,
        mode: str = "hybrid",
    ) -> Dict[str, torch.Tensor]:
        noisy = inputs["noisy_audio"]
        video_frames = inputs["video_frames"]

        encoded_audio = self.audio_encoder(noisy)
        encoded_visual = self.visual_encoder(video_frames)
        _, _, time_steps = encoded_audio.shape
        _, _, vis_feat_size = encoded_visual.shape
        upsampled_visual = F.interpolate(
            encoded_visual.unsqueeze(1),
            size=(time_steps, vis_feat_size),
            mode="bilinear",
        )
        upsampled_visual = (
            upsampled_visual.reshape(-1, time_steps, vis_feat_size).moveaxis(
                1, 2
            )
        )
        encoded_av = torch.cat((upsampled_visual, encoded_audio), dim=1)

        mask = self.separator(encoded_av)
        baseline_latent = mask * encoded_audio
        baseline_audio = self.audio_decoder(baseline_latent)

        if token_steps is None:
            token_steps = self.token_rate_estimator(noisy.shape[-1])

        token_features = self.token_adapter(encoded_av, token_steps)
        token_features = self.token_refiner(token_features)
        token_logits = self.token_head(token_features)
        pred_codes = token_logits.argmax(dim=2)

        if use_hybrid_fusion:
            gate = self.gate(token_features, token_logits)
        else:
            gate = torch.zeros(
                noisy.shape[0], 1, device=noisy.device, dtype=noisy.dtype
            )

        outputs = {
            "baseline_audio": baseline_audio,
            "token_logits": token_logits,
            "pred_codes": pred_codes,
            "gate": gate,
            "token_features": token_features,
        }

        if decode_codec:
            if codec is None or codec_meta is None:
                raise ValueError(
                    "codec and codec_meta are required when decode_codec=True"
                )
            codec_audio = codec.decode_to_16k(
                pred_codes, codec_meta.lengths, codec_meta.scales
            )
            codec_audio = _match_length(codec_audio, baseline_audio)
            outputs["codec_audio"] = codec_audio
            outputs["hybrid_audio"] = (
                gate * codec_audio + (1.0 - gate) * baseline_audio
            )

        if mode == "baseline":
            outputs["final_audio"] = baseline_audio
        elif mode == "codec":
            if "codec_audio" not in outputs:
                raise RuntimeError(
                    "mode='codec' requires decode_codec=True with a codec"
                )
            outputs["final_audio"] = outputs["codec_audio"]
        elif mode == "hybrid":
            if "hybrid_audio" not in outputs:
                raise RuntimeError(
                    "mode='hybrid' requires decode_codec=True with a codec"
                )
            outputs["final_audio"] = outputs["hybrid_audio"]
        else:
            raise ValueError(
                f"Unknown mode '{mode}'. Expected baseline|codec|hybrid."
            )

        return outputs


# =========================================================
# LIGHTNING MODULE
# =========================================================

class AVSEModule(LightningModule):
    def __init__(self, lr=1e-3, val_dataset=None):
        super().__init__()
        self.lr = lr
        self.val_dataset = val_dataset
        self.si_snr = cal_si_snr

        assert sampling_rate == 16000, (
            f"PESQ requires 16 kHz audio; config.sampling_rate={sampling_rate}. "
            "Resample to 16 kHz or adjust this block."
        )
        self.val_pesq = PerceptualEvaluationSpeechQuality(fs=16000, mode="wb")
        self.test_pesq = PerceptualEvaluationSpeechQuality(fs=16000, mode="wb")

        self.pesq_min_len = 4000

        self._pesq_updated = 0
        self._pesq_skipped = 0

        self.codec = (
            EncodecWrapper(
                model_name=encodec_model_name, bandwidth=encodec_bandwidth
            )
            if use_encodec_branch
            else None
        )

        n_q = self.codec.n_q if self.codec is not None else 8
        vocab_size = self.codec.codebook_size if self.codec is not None else 1024
        rate_fn = (
            self.codec.estimate_code_steps
            if self.codec is not None
            else (lambda n: max(1, n // 320))
        )

        self.model = AVSEHybrid(
            n_q=n_q, vocab_size=vocab_size, token_rate_estimator=rate_fn
        )

        self.token_loss = nn.CrossEntropyLoss()
        self.mel = T.MelSpectrogram(
            sample_rate=sampling_rate, n_fft=512, hop_length=160, n_mels=80
        )

        # Freeze codec + force eval mode. Lightning calls .train()
        # on the whole module at every epoch start; the two hooks
        # below (on_*_epoch_start) undo that for the codec.
        if self.codec is not None:
            for p in self.codec.parameters():
                p.requires_grad = False
            self.codec.eval()

        self.save_hyperparameters(ignore=["val_dataset"])

    # ---- Keep EnCodec frozen & in eval mode across epochs ----

    def _freeze_codec(self):
        if self.codec is not None:
            self.codec.eval()
            for p in self.codec.parameters():
                p.requires_grad = False

    def on_train_epoch_start(self):
        self._freeze_codec()

    def on_validation_epoch_start(self):
        self._freeze_codec()

    def on_test_epoch_start(self):
        self._freeze_codec()

    def forward(self, data, **kwargs):
        return self.model(data, **kwargs)

    def _si_snr_mean(self, estimate: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        estimate = _match_length(estimate, target)
        value = self.si_snr(target, estimate)
        return torch.mean(value)

    def _mel_l1(self, estimate: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        estimate = _match_length(estimate, target)
        return F.l1_loss(self.mel(estimate), self.mel(target))

    def cal_loss(self, batch_inp):
        clean = batch_inp["clean"]

        codec_batch = None
        noisy_codec_meta = None
        token_steps = None

        if self.codec is not None:
            codec_batch = self.codec.encode_from_16k(clean.detach())
            token_steps = codec_batch.codes.shape[-1]

        do_decode = bool(
            self.codec is not None
            and decode_encodec_during_training
            and self.current_epoch >= warmup_baseline_epochs,
        )

        if do_decode:
            noisy_codec_meta = self.codec.encode_from_16k(
                batch_inp["noisy_audio"].detach()
            )
            if noisy_codec_meta.codes.shape[-1] != token_steps:
                raise RuntimeError(
                    "Clean/noisy EnCodec token-step mismatch: "
                    f"clean={token_steps}, "
                    f"noisy={noisy_codec_meta.codes.shape[-1]}"
                )

        outputs = self(
            batch_inp,
            token_steps=token_steps,
            decode_codec=do_decode,
            codec=self.codec,
            codec_meta=(noisy_codec_meta if do_decode else None),
            mode="hybrid" if do_decode else "baseline",
        )

        baseline_audio = outputs["baseline_audio"]

        losses = {}
        losses["baseline"] = -self._si_snr_mean(baseline_audio, clean)

        if self.codec is not None:
            token_logits = outputs["token_logits"].permute(
                0, 3, 1, 2
            ).contiguous()
            target_codes = codec_batch.codes.permute(
                0, 2, 1
            ).contiguous()
            losses["token"] = self.token_loss(
                token_logits.view(-1, token_logits.shape[-1]),
                target_codes.view(-1),
            )
        else:
            losses["token"] = torch.tensor(0.0, device=self.device)

        current_baseline_weight = (
            1.0
            if self.current_epoch < warmup_baseline_epochs
            else baseline_loss_weight
        )

        total_loss = current_baseline_weight * losses["baseline"]

        if self.codec is not None:
            total_loss = total_loss + token_loss_weight * losses["token"]

        if do_decode and "codec_audio" in outputs:
            codec_audio = outputs["codec_audio"]
            hybrid_audio = outputs["hybrid_audio"]

            losses["mel"] = self._mel_l1(codec_audio, clean)
            losses["hybrid"] = -self._si_snr_mean(hybrid_audio, clean)

            gate = outputs["gate"]

            with torch.no_grad():
                wave_oracle = _match_length(baseline_audio, clean)
                codec_oracle = _match_length(codec_audio, clean)

                alpha_grid = torch.linspace(
                    0.0,
                    1.0,
                    steps=21,
                    device=clean.device,
                    dtype=clean.dtype,
                )

                oracle_scores = []

                for alpha_candidate in alpha_grid:
                    candidate_audio = (
                        (1.0 - alpha_candidate) * wave_oracle
                        + alpha_candidate * codec_oracle
                    )
                    score = self.si_snr(clean, candidate_audio)

                    if score.ndim == 0:
                        score = score.unsqueeze(0)
                    elif score.ndim > 1:
                        score = score.reshape(score.shape[0], -1).mean(dim=1)

                    oracle_scores.append(score)

                oracle_scores = torch.stack(oracle_scores, dim=1)
                oracle_index = oracle_scores.argmax(dim=1)
                oracle_alpha = alpha_grid[oracle_index].reshape(-1, 1)

            losses["confidence_reg"] = F.mse_loss(gate, oracle_alpha)

            losses["gate_alpha"] = gate.detach().mean()
            losses["oracle_alpha"] = oracle_alpha.detach().mean()
            losses["gate_mae"] = (gate.detach() - oracle_alpha).abs().mean()
            losses["oracle_zero_rate"] = (
                oracle_alpha.detach() <= 1e-8
            ).float().mean()

            if self.current_epoch >= warmup_baseline_epochs:
                total_loss = (
                    total_loss + hybrid_loss_weight * losses["hybrid"]
                )
                total_loss = (
                    total_loss
                    + confidence_reg_weight * losses["confidence_reg"]
                )
        else:
            losses["mel"] = torch.tensor(0.0, device=self.device)
            losses["hybrid"] = torch.tensor(0.0, device=self.device)
            losses["confidence_reg"] = torch.tensor(0.0, device=self.device)
            losses["gate_alpha"] = torch.tensor(0.0, device=self.device)
            losses["oracle_alpha"] = torch.tensor(0.0, device=self.device)
            losses["gate_mae"] = torch.tensor(0.0, device=self.device)
            losses["oracle_zero_rate"] = torch.tensor(0.0, device=self.device)

        return total_loss, losses

    # ---------------- Lightning hooks ----------------

    def training_step(self, batch_inp, batch_idx):
        loss, losses = self.cal_loss(batch_inp)
        bs = batch_inp["clean"].shape[0]
        self.log("loss", loss, on_step=True, on_epoch=True, prog_bar=True,
                 logger=True, batch_size=bs)
        for name, value in losses.items():
            self.log(f"train_{name}", value, on_step=True, on_epoch=True,
                     prog_bar=False, logger=True, batch_size=bs)
        return loss

    def validation_step(self, batch_inp, batch_idx):
        print(f"[VAL] batch {batch_idx} "
              f"clean={tuple(batch_inp['clean'].shape)} "
              f"noisy={tuple(batch_inp['noisy_audio'].shape)} "
              f"video={tuple(batch_inp['video_frames'].shape)}",
              flush=True)
        loss, losses = self.cal_loss(batch_inp)

        with torch.no_grad():
            if self.codec is not None:
                if batch_inp["noisy_audio"].shape[-1] < 400:
                    print(f"[VAL] skip PESQ b={batch_idx}: "
                          f"noisy too short "
                          f"({batch_inp['noisy_audio'].shape[-1]})",
                          flush=True)
                    self._pesq_skipped += 1
                else:
                    pesq_meta = self.codec.encode_from_16k(
                        batch_inp["noisy_audio"].detach()
                    )
                    if pesq_meta.codes.shape[-1] == 0:
                        print(f"[VAL] skip PESQ b={batch_idx}: "
                              f"EnCodec produced 0 tokens", flush=True)
                        self._pesq_skipped += 1
                    else:
                        outputs = self(
                            batch_inp,
                            token_steps=pesq_meta.codes.shape[-1],
                            decode_codec=True,
                            codec=self.codec,
                            codec_meta=pesq_meta,
                            mode="hybrid",
                        )
                        enhanced = outputs["final_audio"].detach()
                        clean = batch_inp["clean"].detach()

                        L = min(enhanced.shape[-1], clean.shape[-1])
                        enhanced = enhanced[..., :L]
                        clean = clean[..., :L]

                        enhanced_cpu = enhanced.float().cpu().double()
                        clean_cpu = clean.float().cpu().double()

                        for i in range(enhanced_cpu.shape[0]):
                            e_i = enhanced_cpu[i]
                            c_i = clean_cpu[i]

                            if e_i.shape[-1] < self.pesq_min_len:
                                self._pesq_skipped += 1
                                continue

                            try:
                                self.val_pesq.update(e_i, c_i)
                                self._pesq_updated += 1
                            except Exception as ex:
                                self._pesq_skipped += 1
                                print(
                                    f"[PESQ] skip b={batch_idx} i={i} "
                                    f"L={e_i.shape[-1]}: {ex}",
                                    flush=True,
                                )

        self.log(
            "val_loss",
            loss,
            on_step=False,
            on_epoch=True,
            prog_bar=True,
            logger=True,
            batch_size=batch_inp["clean"].shape[0],
        )

        for name, value in losses.items():
            self.log(
                f"val_{name}",
                value,
                on_step=False,
                on_epoch=True,
                prog_bar=False,
                logger=True,
                batch_size=batch_inp["clean"].shape[0],
            )

        return loss

    def on_validation_epoch_end(self):
        if self._pesq_updated == 0:
            pesq = torch.tensor(float("nan"))
        else:
            try:
                pesq = self.val_pesq.compute()
            except Exception as ex:
                print(f"[PESQ] compute failed: {ex}", flush=True)
                pesq = torch.tensor(float("nan"))

        # `on_epoch=True` is REQUIRED so ModelCheckpoint sees this.
        self.log(
            "val_pesq",
            pesq,
            on_step=False,
            on_epoch=True,
            prog_bar=True,
            logger=True,
            sync_dist=True,
        )
        self.val_pesq.reset()

        print(
            f"[PESQ] epoch {self.current_epoch}: "
            f"updated={self._pesq_updated} "
            f"skipped={self._pesq_skipped} "
            f"pesq={float(pesq) if pesq == pesq else 'nan'}",
            flush=True,
        )
        self._pesq_updated = 0
        self._pesq_skipped = 0

    def test_step(self, batch_inp, batch_idx):
        with torch.no_grad():
            if self.codec is not None:
                pesq_meta = self.codec.encode_from_16k(
                    batch_inp["noisy_audio"].detach()
                )
                outputs = self(
                    batch_inp,
                    token_steps=pesq_meta.codes.shape[-1],
                    decode_codec=True,
                    codec=self.codec,
                    codec_meta=pesq_meta,
                    mode="hybrid",
                )
            else:
                outputs = self(batch_inp, mode="baseline")

            enhanced = outputs["final_audio"].detach()
            clean = batch_inp["clean"].detach()

            L = min(enhanced.shape[-1], clean.shape[-1])
            enhanced = enhanced[..., :L]
            clean = clean[..., :L]

            enhanced_cpu = enhanced.float().cpu().double()
            clean_cpu = clean.float().cpu().double()

            for i in range(enhanced_cpu.shape[0]):
                e_i = enhanced_cpu[i]
                c_i = clean_cpu[i]
                if e_i.shape[-1] < self.pesq_min_len:
                    continue
                try:
                    self.test_pesq.update(e_i, c_i)
                except Exception as ex:
                    print(
                        f"[PESQ-TEST] skip b={batch_idx} i={i}: {ex}",
                        flush=True,
                    )

    def on_test_epoch_end(self):
        try:
            pesq = self.test_pesq.compute()
        except Exception:
            pesq = torch.tensor(float("nan"))
        self.log("test_pesq", pesq, on_step=False, on_epoch=True,
                 prog_bar=True, logger=True)
        self.test_pesq.reset()
        print(f"[PESQ-TEST] final test_pesq = {float(pesq):.4f}", flush=True)

    # ---------------- Inference ----------------

    def enhance(self, data, mode: Optional[str] = None):
        mode = mode or inference_mode
        noisy = torch.from_numpy(data["noisy_audio"][np.newaxis, ...]).to(
            self.device
        )
        video = torch.from_numpy(data["video_frames"][np.newaxis, ...]).to(
            self.device
        )
        inputs = {"noisy_audio": noisy, "video_frames": video}

        codec_meta = None
        token_steps = None
        if self.codec is not None and mode in {"codec", "hybrid"}:
            codec_meta = self.codec.encode_from_16k(noisy)
            token_steps = codec_meta.codes.shape[-1]

        outputs = self(
            inputs,
            token_steps=token_steps,
            decode_codec=codec_meta is not None,
            codec=self.codec,
            codec_meta=codec_meta,
            mode=mode,
        )
        estimated_audio = outputs["final_audio"].detach().cpu().numpy()
        return estimated_audio

    def on_train_epoch_end(self):
        if self.val_dataset is None:
            return
        try:
            with torch.no_grad():
                tensorboard = self.logger.experiment
                for index in range(5):
                    rand_int = random.randint(0, len(self.val_dataset) - 1)
                    data = self.val_dataset[rand_int]
                    estimated_audio = self.enhance(data)
                    tensorboard.add_audio(
                        f"{self.current_epoch}/{index}_clean",
                        data["clean"][np.newaxis, ...],
                        sample_rate=sampling_rate,
                    )
                    tensorboard.add_audio(
                        f"{self.current_epoch}/{index}_noisy",
                        data["noisy_audio"][np.newaxis, ...],
                        sample_rate=sampling_rate,
                    )
                    tensorboard.add_audio(
                        f"{self.current_epoch}/{index}_enhanced",
                        estimated_audio.reshape(-1)[np.newaxis, ...],
                        sample_rate=sampling_rate,
                    )
        except Exception as ex:
            print(f"[TRAIN] audio logging skipped: {ex}", flush=True)

    # ---------------- Optim / scheduler ----------------

    def configure_optimizers(self):
        optimizer = torch.optim.RMSprop(self.parameters(), lr=self.lr)
        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": ReduceLROnPlateau(
                    optimizer, factor=0.8, patience=5
                ),
                "monitor": "val_loss",
            },
        }