import math

import torch
import torch.nn as nn
import torchvision


# ============================================================
# SI-SNR
# ============================================================

def cal_si_snr(source, estimate_source, eps=1e-8):
    """
    Compute positive Scale-Invariant Signal-to-Noise Ratio (SI-SNR).

    Parameters
    ----------
    source : torch.Tensor
        Clean/reference waveform.
        Supported shapes:
            [T]
            [B, T]
            [B, T, C]

    estimate_source : torch.Tensor
        Estimated/enhanced waveform.
        Must have the same shape as source.

    eps : float
        Numerical stability constant.

    Returns
    -------
    torch.Tensor
        Positive SI-SNR in dB for each batch item/channel.

    Convention
    ----------
    First argument:
        clean/reference signal

    Second argument:
        estimated/enhanced signal

    IMPORTANT:
        This function returns POSITIVE SI-SNR.

        Therefore, when SI-SNR is used as a training loss:

            loss = -cal_si_snr(clean, estimate).mean()

        because the optimizer minimizes the loss.
    """

    # --------------------------------------------------------
    # Check input shapes
    # --------------------------------------------------------

    if source.shape != estimate_source.shape:
        raise ValueError(
            f"SI-SNR shape mismatch: "
            f"source={tuple(source.shape)}, "
            f"estimate={tuple(estimate_source.shape)}"
        )

    source = source.float()
    estimate_source = estimate_source.float()

    # --------------------------------------------------------
    # Standardize input to [B, T, C]
    # --------------------------------------------------------

    if source.dim() == 1:

        # [T] -> [1, T, 1]
        source = source.unsqueeze(0).unsqueeze(-1)
        estimate_source = estimate_source.unsqueeze(0).unsqueeze(-1)

    elif source.dim() == 2:

        # [B, T] -> [B, T, 1]
        source = source.unsqueeze(-1)
        estimate_source = estimate_source.unsqueeze(-1)

    elif source.dim() == 3:

        # Already [B, T, C]
        pass

    else:

        raise ValueError(
            "cal_si_snr expects tensors with shape "
            "[T], [B,T], or [B,T,C]. "
            f"Received {tuple(source.shape)}"
        )

    # --------------------------------------------------------
    # Remove DC component
    #
    # Time is dimension 1 because representation is [B,T,C].
    # --------------------------------------------------------

    source_zero_mean = (
        source
        - source.mean(
            dim=1,
            keepdim=True
        )
    )

    estimate_zero_mean = (
        estimate_source
        - estimate_source.mean(
            dim=1,
            keepdim=True
        )
    )

    # --------------------------------------------------------
    # Projection of estimate onto clean/reference speech
    #
    # s_target =
    #
    #       <s_hat, s>
    #       ------------ s
    #          ||s||²
    # --------------------------------------------------------

    source_energy = (
        torch.sum(
            source_zero_mean ** 2,
            dim=1,
            keepdim=True
        )
        + eps
    )

    dot_product = torch.sum(
        estimate_zero_mean * source_zero_mean,
        dim=1,
        keepdim=True
    )

    projection = (
        dot_product
        * source_zero_mean
        / source_energy
    )

    # --------------------------------------------------------
    # Residual/error
    # --------------------------------------------------------

    noise = (
        estimate_zero_mean
        - projection
    )

    # --------------------------------------------------------
    # Signal and noise energy
    # --------------------------------------------------------

    projection_energy = torch.sum(
        projection ** 2,
        dim=1
    )

    noise_energy = (
        torch.sum(
            noise ** 2,
            dim=1
        )
        + eps
    )

    # --------------------------------------------------------
    # SI-SNR
    # --------------------------------------------------------

    ratio = (
        projection_energy
        / noise_energy
    )

    si_snr = (
        10.0
        * torch.log10(
            ratio + eps
        )
    )

    return si_snr


# ============================================================
# ACTIVATION
# ============================================================

class Swish(nn.Module):

    def forward(self, x):

        return x * torch.sigmoid(x)


# ============================================================
# RESNET UTILITIES
# ============================================================

def conv3x3(in_planes, out_planes, stride=1):

    return nn.Conv2d(
        in_planes,
        out_planes,
        kernel_size=3,
        stride=stride,
        padding=1,
        bias=False
    )


def downsample_basic_block(
    inplanes,
    outplanes,
    stride
):

    return nn.Sequential(

        nn.Conv2d(
            inplanes,
            outplanes,
            kernel_size=1,
            stride=stride,
            bias=False
        ),

        nn.BatchNorm2d(
            outplanes
        )
    )


def downsample_basic_block_v2(
    inplanes,
    outplanes,
    stride
):

    return nn.Sequential(

        nn.AvgPool2d(
            kernel_size=stride,
            stride=stride,
            ceil_mode=True,
            count_include_pad=False
        ),

        nn.Conv2d(
            inplanes,
            outplanes,
            kernel_size=1,
            stride=1,
            bias=False
        ),

        nn.BatchNorm2d(
            outplanes
        )
    )


# ============================================================
# BASIC RESNET BLOCK
# ============================================================

class BasicBlock(nn.Module):

    expansion = 1

    def __init__(
        self,
        inplanes,
        planes,
        stride=1,
        downsample=None,
        relu_type='prelu'
    ):

        super(BasicBlock, self).__init__()

        assert relu_type in [
            'relu',
            'prelu',
            'swish'
        ]

        # ----------------------------------------------------
        # First convolution
        # ----------------------------------------------------

        self.conv1 = conv3x3(
            inplanes,
            planes,
            stride
        )

        self.bn1 = nn.BatchNorm2d(
            planes
        )

        # ----------------------------------------------------
        # Activation
        # ----------------------------------------------------

        if relu_type == 'relu':

            self.relu1 = nn.ReLU(
                inplace=True
            )

            self.relu2 = nn.ReLU(
                inplace=True
            )

        elif relu_type == 'prelu':

            self.relu1 = nn.PReLU(
                num_parameters=planes
            )

            self.relu2 = nn.PReLU(
                num_parameters=planes
            )

        elif relu_type == 'swish':

            self.relu1 = Swish()
            self.relu2 = Swish()

        else:

            raise Exception(
                'relu type not implemented'
            )

        # ----------------------------------------------------
        # Second convolution
        # ----------------------------------------------------

        self.conv2 = conv3x3(
            planes,
            planes
        )

        self.bn2 = nn.BatchNorm2d(
            planes
        )

        self.downsample = downsample
        self.stride = stride

    def forward(self, x):

        residual = x

        # First convolution
        out = self.conv1(x)

        out = self.bn1(out)

        out = self.relu1(out)

        # Second convolution
        out = self.conv2(out)

        out = self.bn2(out)

        # Match dimensions if necessary
        if self.downsample is not None:

            residual = self.downsample(x)

        # Residual connection
        out += residual

        out = self.relu2(out)

        return out


# ============================================================
# RESNET
# ============================================================

class ResNet(nn.Module):

    def __init__(
        self,
        block,
        layers,
        relu_type='relu',
        gamma_zero=False,
        avg_pool_downsample=False,
        in_channels=64
    ):

        self.inplanes = in_channels

        self.relu_type = relu_type

        self.gamma_zero = gamma_zero

        self.downsample_block = (
            downsample_basic_block_v2
            if avg_pool_downsample
            else downsample_basic_block
        )

        super(ResNet, self).__init__()

        # ----------------------------------------------------
        # Residual stages
        # ----------------------------------------------------

        self.layer1 = self._make_layer(
            block,
            64,
            layers[0]
        )

        self.layer2 = self._make_layer(
            block,
            128,
            layers[1],
            stride=2
        )

        self.layer3 = self._make_layer(
            block,
            256,
            layers[2],
            stride=2
        )

        self.layer4 = self._make_layer(
            block,
            512,
            layers[3],
            stride=2
        )

        self.avgpool = nn.AdaptiveAvgPool2d(
            1
        )

        # ----------------------------------------------------
        # Weight initialization
        # ----------------------------------------------------

        for m in self.modules():

            if isinstance(
                m,
                nn.Conv2d
            ):

                n = (
                    m.kernel_size[0]
                    * m.kernel_size[1]
                    * m.out_channels
                )

                m.weight.data.normal_(
                    0,
                    math.sqrt(
                        2.0 / n
                    )
                )

            elif isinstance(
                m,
                nn.BatchNorm2d
            ):

                m.weight.data.fill_(
                    1
                )

                m.bias.data.zero_()

        # ----------------------------------------------------
        # Optional zero-gamma initialization
        # ----------------------------------------------------

        if self.gamma_zero:

            for m in self.modules():

                if isinstance(
                    m,
                    BasicBlock
                ):

                    m.bn2.weight.data.zero_()

    def _make_layer(
        self,
        block,
        planes,
        blocks,
        stride=1
    ):

        downsample = None

        if (
            stride != 1
            or
            self.inplanes
            != planes * block.expansion
        ):

            downsample = self.downsample_block(
                inplanes=self.inplanes,
                outplanes=(
                    planes
                    * block.expansion
                ),
                stride=stride
            )

        layers = []

        layers.append(

            block(
                self.inplanes,
                planes,
                stride,
                downsample,
                relu_type=self.relu_type
            )

        )

        self.inplanes = (
            planes
            * block.expansion
        )

        for _ in range(
            1,
            blocks
        ):

            layers.append(

                block(
                    self.inplanes,
                    planes,
                    relu_type=self.relu_type
                )

            )

        return nn.Sequential(
            *layers
        )

    def forward(self, x):

        x = self.layer1(x)

        x = self.layer2(x)

        x = self.layer3(x)

        x = self.layer4(x)

        x = self.avgpool(x)

        x = x.view(
            x.size(0),
            -1
        )

        return x


# ============================================================
# SHUFFLENET
# ============================================================

class ShuffleNet(nn.Module):

    def __init__(self):

        super(
            ShuffleNet,
            self
        ).__init__()

        self.model = nn.Sequential(

            torchvision.models.shufflenet_v2_x0_5(
                weights=None,
                num_classes=512
            ),

            # Keep this layer unchanged.
            nn.Linear(
                512,
                256,
                bias=False
            ),

            nn.PReLU(),

            nn.LayerNorm(
                256
            )
        )

    def forward(self, x):

        B, N, C, H, W = x.shape

        x = x.reshape(
            B * N,
            C,
            H,
            W
        )

        x = self.model(x)

        x = x.reshape(
            B,
            N,
            -1
        )

        return x


# ============================================================
# SIMPLE TEST
# ============================================================

if __name__ == "__main__":

    model = ShuffleNet()

    result = model(
        torch.rand(
            1,
            75,
            3,
            96,
            96
        )
    )

    print(
        "ShuffleNet output shape:",
        result.shape
    )

    # --------------------------------------------------------
    # SI-SNR sanity test
    # --------------------------------------------------------

    clean = torch.randn(
        2,
        48000
    )

    # Near-perfect estimate
    estimate_good = (
        clean
        + 0.01
        * torch.randn_like(clean)
    )

    # Poor estimate
    estimate_bad = torch.randn_like(
        clean
    )

    good_sisnr = cal_si_snr(
        clean,
        estimate_good
    )

    bad_sisnr = cal_si_snr(
        clean,
        estimate_bad
    )

    print(
        "Good estimate SI-SNR:",
        good_sisnr.mean().item(),
        "dB"
    )

    print(
        "Bad estimate SI-SNR:",
        bad_sisnr.mean().item(),
        "dB"
    )