from __future__ import annotations

from typing import Sequence, TypeVar, List

T = TypeVar("T")


def subsample_list(items: Sequence[T], sample_rate: int = 1) -> List[T]:
    """Return every `sample_rate`-th item from a sequence.

    The dataset loader imports this helper when optional dataset subsampling is used.
    `sample_rate=1` keeps the list unchanged.
    """
    sample_rate = int(sample_rate)
    if sample_rate <= 0:
        raise ValueError("sample_rate must be a positive integer")
    return list(items)[::sample_rate]
