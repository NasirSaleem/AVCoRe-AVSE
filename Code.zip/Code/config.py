from os.path import isfile
SEED = 1143
sampling_rate = 16000
max_frames = 75
max_audio_len = sampling_rate * 3
img_height = 128
img_width = 128
encodec_model_name = "24khz"
encodec_bandwidth = 6.0
use_encodec_branch = True
warmup_baseline_epochs = 10
use_hybrid_fusion = True
use_gate_entropy = True
token_loss_weight = 1.0
baseline_loss_weight = 0.5
hybrid_loss_weight = 1.0
confidence_reg_weight = 0.01
decode_encodec_during_training = True
inference_mode = "hybrid"
DATA_ROOT = "data/"
assert not isfile(DATA_ROOT), "Please set DATA_ROOT in config.py to the correct path to the avsec dataset"