from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torchaudio.functional as AF


@dataclass
class EncodecBatch:
    codes: torch.Tensor               # [B, n_q, T]
    scales: List[Optional[torch.Tensor]]
    lengths: List[int]


class EncodecWrapper(nn.Module):
    """Wrapper around the official facebookresearch/encodec package.

    This class is intentionally inference-only for the codec itself. We freeze
    the codec and train only the AV model to predict EnCodec codes.
    """

    def __init__(self, model_name: str = "24khz", bandwidth: float = 6.0):
        super().__init__()
        try:
            from encodec import EncodecModel
        except ImportError as exc:
            raise ImportError(
                "The official `encodec` package is required. Install with `pip install -U encodec`."
            ) from exc

        if model_name != "24khz":
            raise ValueError("This implementation currently supports EnCodec 24kHz mono only.")

        model = EncodecModel.encodec_model_24khz()
        model.set_target_bandwidth(float(bandwidth))
        model.eval()
        for param in model.parameters():
            param.requires_grad = False

        self.model = model
        self.bandwidth = float(bandwidth)
        self.sample_rate = int(model.sample_rate)
        self.channels = int(model.channels)
        self.codebook_size = int(getattr(model.quantizer, "bins", 1024))
        self.n_q = self._infer_num_codebooks()
        self.token_rate = self._infer_token_rate_16k()

    # [FIX] Force the codec to ALWAYS stay in eval mode.
    #
    # PyTorch Lightning calls `module.train()` recursively on the whole
    # model at the start of every epoch. Without this override, the inner
    # EncodecModel (which we froze in __init__) would be flipped back to
    # train mode, re-enabling its BatchNorm running-stat updates and its
    # LSTM dropout. That would silently corrupt the codec codes we use as
    # supervision targets and would make training non-reproducible.
    #
    # By overriding `train()` on the wrapper, we intercept the recursive
    # call and keep both the wrapper and its inner model in eval mode.
    def train(self, mode: bool = True):
        super().train(False)
        self.model.eval()
        return self

    def _infer_num_codebooks(self) -> int:
        dummy = torch.zeros(1, self.channels, self.sample_rate)
        device = next(self.model.parameters()).device
        with torch.no_grad():
            frames = self.model.encode(dummy.to(device))
        codes = torch.cat([frame[0] for frame in frames], dim=-1)
        return int(codes.shape[1])

    def _infer_token_rate_16k(self) -> float:
        dummy_16k = torch.zeros(1, 16000)
        batch = self.encode_from_16k(dummy_16k)
        return float(batch.codes.shape[-1])

    def estimate_code_steps(self, audio_num_samples_16k: int) -> int:
        seconds = float(audio_num_samples_16k) / 16000.0
        return max(1, int(round(seconds * self.token_rate)))

    def preprocess(self, audio_16k: torch.Tensor) -> torch.Tensor:
        if audio_16k.dim() == 1:
            audio_16k = audio_16k.unsqueeze(0)
        if audio_16k.dim() != 2:
            raise ValueError(f"Expected [B, T] audio, got shape {tuple(audio_16k.shape)}")

        audio = audio_16k.unsqueeze(1)
        if self.sample_rate != 16000:
            audio = AF.resample(audio, 16000, self.sample_rate)
        if audio.shape[1] != self.channels:
            if self.channels == 1:
                audio = audio.mean(dim=1, keepdim=True)
            else:
                audio = audio.repeat(1, self.channels, 1)
        return audio.contiguous()

    @torch.no_grad()
    def encode_from_16k(self, audio_16k: torch.Tensor) -> EncodecBatch:
        audio = self.preprocess(audio_16k)
        device = next(self.model.parameters()).device
        frames = self.model.encode(audio.to(device))
        codes = torch.cat([frame[0] for frame in frames], dim=-1).long()
        scales = [frame[1] for frame in frames]
        lengths = [int(frame[0].shape[-1]) for frame in frames]
        return EncodecBatch(codes=codes, scales=scales, lengths=lengths)

    def split_codes(self, codes: torch.Tensor, lengths: Sequence[int], scales: Sequence[Optional[torch.Tensor]]):
        chunks = []
        start = 0
        for length, scale in zip(lengths, scales):
            end = start + int(length)
            chunks.append((codes[:, :, start:end], scale))
            start = end
        return chunks

    @torch.no_grad()
    def decode_to_16k(
        self,
        codes: torch.Tensor,
        lengths: Sequence[int],
        scales: Sequence[Optional[torch.Tensor]],
    ) -> torch.Tensor:
        frames = self.split_codes(codes, lengths, scales)
        wav = self.model.decode(frames)

        if wav.dim() == 3:
            wav = wav[:, 0, :]
        else:
            wav = wav.squeeze(1)

        if self.sample_rate != 16000:
            wav = AF.resample(
                wav.unsqueeze(1),
                self.sample_rate,
                16000
            ).squeeze(1)

        return wav