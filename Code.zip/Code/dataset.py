import logging
import os
import random
from os.path import isfile, join

import cv2
import numpy as np
import torch
from decord import VideoReader, cpu
from pytorch_lightning import LightningDataModule
from scipy.io import wavfile
from torch.utils.data import Dataset

from config import DATA_ROOT, SEED, img_height, img_width
from utils import subsample_list


AUDIO_LEN = 48000
AUDIO_SR = 16000
VIDEO_FPS = 25
VIDEO_LEN = 75


class AVSEDataset(Dataset):

    def __init__(
        self,
        scenes_root,
        shuffle=False,
        seed=SEED,
        subsample=1,
        clipped_batch=True,
        random_crop=False,
        test_set=False,
    ):
        super().__init__()

        self.test_set = test_set
        self.clipped_batch = clipped_batch
        self.random_crop = random_crop
        self.scenes_root = scenes_root

        self.files_list = self.build_files_list

        if shuffle:
            rng = random.Random(seed)
            rng.shuffle(self.files_list)

        if subsample != 1:
            self.files_list = subsample_list(
                self.files_list,
                sample_rate=subsample,
            )

        logging.info(
            "Found %d utterances",
            len(self.files_list),
        )

    @property
    def build_files_list(self):

        files_list = []

        for file in sorted(os.listdir(self.scenes_root)):

            if file.endswith("mixed.wav"):

                files = (
                    join(
                        self.scenes_root,
                        file.replace("mixed", "target"),
                    ),
                    join(
                        self.scenes_root,
                        file.replace("mixed", "interferer"),
                    ),
                    join(
                        self.scenes_root,
                        file,
                    ),
                    join(
                        self.scenes_root,
                        file.replace(
                            "_mixed.wav",
                            "_silent.mp4",
                        ),
                    ),
                )

                if not self.test_set:

                    if all(isfile(f) for f in files):
                        files_list.append(files)

                else:
                    files_list.append(files)

        return files_list

    def __len__(self):
        return len(self.files_list)

    def __getitem__(self, idx):

        clean_file, noise_file, noisy_file, mp4_file = \
            self.files_list[idx]

        noisy_audio, clean, video_frames = self.get_data(
            clean_file,
            noise_file,
            noisy_file,
            mp4_file,
        )

        return {
            "noisy_audio": noisy_audio,
            "clean": clean,
            "video_frames": video_frames,
            "scene": clean_file.replace(
                self.scenes_root, ""
            ).replace(
                "_target.wav", ""
            ).replace("/", ""),
        }

    def load_wav(self, wav_path):

        sr, audio = wavfile.read(wav_path)

        if sr != AUDIO_SR:
            raise ValueError(
                f"Expected {AUDIO_SR} Hz audio, "
                f"but {wav_path} has {sr} Hz."
            )

        if audio.dtype == np.int16:
            audio = audio.astype(np.float32) / 32768.0
        else:
            audio = audio.astype(np.float32)

        if audio.ndim != 1:
            raise ValueError(
                f"Expected mono audio, got "
                f"{audio.shape} for {wav_path}"
            )

        return audio

    def resize_video_frames(self, frames):

        resized_frames = []

        for frame in frames:

            bgr_frame = frame[:, :, [2, 1, 0]]

            resized_frames.append(
                cv2.resize(
                    bgr_frame,
                    (img_width, img_height),
                )
            )

        return resized_frames

    def enhanced_frames(self, frames):

        out = np.zeros_like(frames)

        for i in range(len(frames)):

            b, g, r = cv2.split(frames[i])

            out[i] = cv2.merge([
                cv2.equalizeHist(b),
                cv2.equalizeHist(g),
                cv2.equalizeHist(r),
            ])

        return out

    def get_data(
        self,
        clean_file,
        noise_file,
        noisy_file,
        mp4_file,
    ):

        noisy = self.load_wav(noisy_file)

        clean = (
            self.load_wav(clean_file)
            if isfile(clean_file)
            else np.zeros_like(noisy)
        )

        if clean.shape[0] != noisy.shape[0]:
            min_len = min(
                clean.shape[0],
                noisy.shape[0],
            )
            clean = clean[:min_len]
            noisy = noisy[:min_len]

        vr = VideoReader(
            mp4_file,
            ctx=cpu(0),
        )

        if self.clipped_batch:

            if clean.shape[0] > AUDIO_LEN:

                max_start = clean.shape[0] - AUDIO_LEN

                if self.random_crop:
                    clip_idx = random.randint(
                        0,
                        max_start,
                    )
                else:
                    clip_idx = max_start // 2

                video_idx = int(
                    (clip_idx / AUDIO_SR) * VIDEO_FPS
                )

                clean = clean[
                    clip_idx:clip_idx + AUDIO_LEN
                ]

                noisy = noisy[
                    clip_idx:clip_idx + AUDIO_LEN
                ]

            else:

                video_idx = 0

                clean = np.pad(
                    clean,
                    (0, AUDIO_LEN - clean.shape[0]),
                    mode="constant",
                )

                noisy = np.pad(
                    noisy,
                    (0, AUDIO_LEN - noisy.shape[0]),
                    mode="constant",
                )

            if len(vr) == 0:
                raise RuntimeError(
                    f"No video frames found: {mp4_file}"
                )

            max_video_start = max(
                0,
                len(vr) - VIDEO_LEN,
            )

            video_idx = min(
                max(video_idx, 0),
                max_video_start,
            )

            end_idx = min(
                video_idx + VIDEO_LEN,
                len(vr),
            )

            frame_indices = list(
                range(video_idx, end_idx)
            )

            frames = vr.get_batch(
                frame_indices
            ).asnumpy()

            frames = self.resize_video_frames(
                frames
            )

            frames = self.enhanced_frames(
                np.asarray(frames)
            )

            bg_frames = np.array(
                [
                    cv2.cvtColor(
                        frames[i],
                        cv2.COLOR_RGB2GRAY,
                    )
                    for i in range(len(frames))
                ],
                dtype=np.float32,
            )

            bg_frames /= 255.0

            if len(bg_frames) < VIDEO_LEN:

                padding = np.zeros(
                    (
                        VIDEO_LEN - len(bg_frames),
                        img_height,
                        img_width,
                    ),
                    dtype=np.float32,
                )

                bg_frames = np.concatenate(
                    (bg_frames, padding),
                    axis=0,
                )

        else:

            frames = vr.get_batch(
                list(range(len(vr)))
            ).asnumpy()

            frames = self.resize_video_frames(
                frames
            )

            frames = self.enhanced_frames(
                np.asarray(frames)
            )

            bg_frames = np.array(
                [
                    cv2.cvtColor(
                        frames[i],
                        cv2.COLOR_RGB2GRAY,
                    )
                    for i in range(len(frames))
                ],
                dtype=np.float32,
            )

            bg_frames /= 255.0

        return (
            noisy.astype(np.float32),
            clean.astype(np.float32),
            bg_frames[np.newaxis, ...].astype(np.float32),
        )


class AVSEDataModule(LightningDataModule):

    def __init__(self, batch_size=8):

        super().__init__()

        # Training:
        # random 3-second crops.
        self.train_dataset_batch = AVSEDataset(
            join(DATA_ROOT, "train/scenes"),
            clipped_batch=True,
            random_crop=True,
        )

        # Validation:
        # deterministic 3-second centre crops.
        self.dev_dataset_batch = AVSEDataset(
            join(DATA_ROOT, "dev/scenes"),
            clipped_batch=True,
            random_crop=False,
        )

        # Full utterances for evaluation.
        self.dev_dataset = AVSEDataset(
            join(DATA_ROOT, "dev/scenes"),
            clipped_batch=False,
            random_crop=False,
        )

        self.eval_dataset = AVSEDataset(
            join(DATA_ROOT, "eval/scenes"),
            clipped_batch=False,
            random_crop=False,
            test_set=True,
        )

        self.batch_size = batch_size

    def train_dataloader(self):

        assert len(self.train_dataset_batch) > 0, \
            "No training data found"

        return torch.utils.data.DataLoader(
            self.train_dataset_batch,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=4,
            pin_memory=True,
            persistent_workers=True,
        )

    def val_dataloader(self):

        assert len(self.dev_dataset_batch) > 0, \
            "No validation data found"

        return torch.utils.data.DataLoader(
            self.dev_dataset_batch,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=4,
            pin_memory=True,
            persistent_workers=True,
        )

    def test_dataloader(self):

        return torch.utils.data.DataLoader(
            self.dev_dataset,
            batch_size=1,
            shuffle=False,
            num_workers=0,
        )