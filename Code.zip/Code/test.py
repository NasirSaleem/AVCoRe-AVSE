from argparse import ArgumentParser
from os import makedirs
from os.path import join

import soundfile as sf
import torch
from tqdm import tqdm

from config import inference_mode, sampling_rate
from dataset import AVSEDataModule
from model import AVSEModule
from utils import str2bool


def main(args):

    # -----------------------------------------------------
    # Output directory
    # -----------------------------------------------------

    enhanced_root = join(
        args.save_root,
        args.model_uid
    )

    makedirs(
        enhanced_root,
        exist_ok=True
    )

    # -----------------------------------------------------
    # Dataset
    # -----------------------------------------------------

    datamodule = AVSEDataModule(
        batch_size=1
    )

    if args.dev_set and args.eval_set:
        raise RuntimeError(
            "Select either dev set or eval set, not both."
        )

    if args.dev_set:
        dataset = datamodule.dev_dataset

    elif args.eval_set:
        dataset = datamodule.eval_dataset

    else:
        raise RuntimeError(
            "Select either --dev_set true "
            "or --eval_set true."
        )

    # -----------------------------------------------------
    # Device
    # -----------------------------------------------------

    if args.cpu:
        device = torch.device("cpu")
    else:
        device = torch.device(
            "cuda:0"
            if torch.cuda.is_available()
            else "cpu"
        )

    print(f"Using device: {device}")

    # -----------------------------------------------------
    # Load checkpoint
    # -----------------------------------------------------

    try:
        model = AVSEModule.load_from_checkpoint(
            args.ckpt_path,
            map_location=device,
        )

    except Exception as exc:
        raise RuntimeError(
            f"Cannot load checkpoint: "
            f"{args.ckpt_path}"
        ) from exc

    model = model.to(device)
    model.eval()

    print(
        f"Model loaded: {args.ckpt_path}"
    )

    # -----------------------------------------------------
    # Inference mode
    # -----------------------------------------------------

    mode = (
        args.mode
        if args.mode is not None
        else inference_mode
    )

    print(f"Inference mode: {mode}")
    print(f"Number of utterances: {len(dataset)}")

    # -----------------------------------------------------
    # Enhancement
    # -----------------------------------------------------

    with torch.inference_mode():

        for i in tqdm(
            range(len(dataset)),
            desc=f"Enhancing ({mode})"
        ):

            data = dataset[i]

            scene = str(data["scene"]).lstrip(
                "/\\"
            )

            filename = f"{scene}.wav"

            enhanced_path = join(
                enhanced_root,
                filename
            )

            estimated_audio = model.enhance(
                data,
                mode=mode
            ).reshape(-1)

            # Safety check only.
            # DO NOT peak-normalize model output.
            if not torch.isfinite(
                torch.from_numpy(estimated_audio)
            ).all():

                raise RuntimeError(
                    f"Non-finite output detected "
                    f"for scene {scene}"
                )

            sf.write(
                enhanced_path,
                estimated_audio,
                samplerate=sampling_rate,
                subtype="FLOAT",
            )

    print("\nInference complete.")
    print(f"Outputs saved to: {enhanced_root}")


if __name__ == "__main__":

    parser = ArgumentParser()

    parser.add_argument(
        "--ckpt_path",
        type=str,
        required=True,
        help="Path to model checkpoint",
    )

    parser.add_argument(
        "--save_root",
        type=str,
        required=True,
        help="Root directory for enhanced audio",
    )

    parser.add_argument(
        "--model_uid",
        type=str,
        required=True,
        help="Output folder name",
    )

    parser.add_argument(
        "--dev_set",
        type=str2bool,
        default=False,
        help="Evaluate on development set",
    )

    parser.add_argument(
        "--eval_set",
        type=str2bool,
        default=False,
        help="Evaluate on evaluation set",
    )

    parser.add_argument(
        "--cpu",
        type=str2bool,
        default=False,
        help="Run inference on CPU",
    )

    parser.add_argument(
        "--mode",
        type=str,
        default=None,
        choices=[
            "baseline",
            "codec",
            "hybrid",
        ],
        help=(
            "Output branch. If omitted, "
            "config.inference_mode is used."
        ),
    )

    args = parser.parse_args()

    main(args)