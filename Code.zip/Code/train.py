import warnings
import faulthandler

from argparse import ArgumentParser

import numpy as np
import torch
import pytorch_lightning as pl
from pytorch_lightning import Trainer
from pytorch_lightning.callbacks import ModelCheckpoint

from config import SEED
from dataset import AVSEDataModule
from model import AVSEModule

# Enable faulthandler EARLY (before heavy imports) so a segfault
# in a C extension (EnCodec, PESQ, soundfile) prints a traceback
# instead of silently killing the process.
faulthandler.enable()

# The frozen EnCodec stays in eval mode; silence the harmless
# warning Lightning emits about modules in eval mode.
warnings.filterwarnings(
    "ignore",
    message=r"Found \d+ module\(s\) in eval mode",
)


# ---------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------

pl.seed_everything(SEED, workers=True)

torch.backends.cudnn.deterministic = False
torch.backends.cudnn.benchmark = True
torch.set_float32_matmul_precision("medium")

np.random.seed(SEED)
torch.manual_seed(SEED)


def main(args):

    # -----------------------------------------------------
    # Dataset
    # -----------------------------------------------------

    datamodule = AVSEDataModule(batch_size=args.batch_size)

    # -----------------------------------------------------
    # Model
    # -----------------------------------------------------

    model = AVSEModule(
        val_dataset=datamodule.dev_dataset,
        lr=args.lr,
    )

    print("\n==============================================")
    print("CoRe-Net: Oracle-Guided Gate Training")
    print("==============================================")
    print(f"Learning rate : {args.lr}")
    print(f"Batch size    : {args.batch_size}")
    print(f"Max epochs    : {args.max_epochs_no}")
    print(f"Checkpoint    : {args.ckpt_path}")
    print("==============================================\n")

    # -----------------------------------------------------
    # Best-model checkpointing (keyed on PESQ)
    # -----------------------------------------------------
    # save_top_k=3 keeps the three best-PESQ checkpoints.
    # save_last=True always writes last.ckpt at the end of
    # every epoch so training can resume.
    # -----------------------------------------------------

    checkpoint_callback = ModelCheckpoint(
        monitor="val_pesq",
        mode="max",
        save_top_k=3,
        save_last=True,
        filename="epoch={epoch:03d}-pesq={val_pesq:.4f}",
        auto_insert_metric_name=False,
    )

    # -----------------------------------------------------
    # Trainer
    # -----------------------------------------------------

    trainer = Trainer(
        default_root_dir=args.log_dir,
        callbacks=[checkpoint_callback],
        accelerator="gpu" if torch.cuda.is_available() else "cpu",
        devices=1,
        max_epochs=args.max_epochs_no,
        deterministic=False,
        log_every_n_steps=10,
    )

    # -----------------------------------------------------
    # Training
    # -----------------------------------------------------

    trainer.fit(
        model,
        datamodule=datamodule,
        ckpt_path=args.ckpt_path,
    )

    # -----------------------------------------------------
    # Final information
    # -----------------------------------------------------

    print("\n==============================================")
    print("Oracle-guided gate training complete.")
    print("==============================================")
    print("Best checkpoint:")
    print(checkpoint_callback.best_model_path)
    print("Best validation PESQ:", checkpoint_callback.best_model_score)

    # -----------------------------------------------------
    # Final test on the best-PESQ checkpoint
    # -----------------------------------------------------
    # Only runs if AVSEDataModule exposes a test set.
    # Otherwise this block is skipped silently.
    # -----------------------------------------------------

    has_test = hasattr(datamodule, "test_dataloader") and (
        getattr(datamodule, "test_dataset", None) is not None
        or getattr(datamodule, "test_ds", None) is not None
    )

    if has_test and checkpoint_callback.best_model_path:
        print("\nRunning final test on best checkpoint...")
        trainer.test(
            model,
            datamodule=datamodule,
            ckpt_path=checkpoint_callback.best_model_path,
        )
    else:
        print(
            "\nNo test set found on AVSEDataModule — "
            "skipping trainer.test()."
        )


if __name__ == "__main__":

    parser = ArgumentParser()

    parser.add_argument(
        "--batch_size",
        type=int,
        default=8,
        help="Training batch size",
    )

    parser.add_argument(
        "--lr",
        type=float,
        default=1e-3,
        help="Initial learning rate",
    )

    parser.add_argument(
        "--log_dir",
        type=str,
        required=True,
        help="Directory for checkpoints and logs",
    )

    parser.add_argument(
        "--max_epochs_no",
        type=int,
        default=100,
        help="Maximum number of training epochs",
    )

    parser.add_argument(
        "--ckpt_path",
        type=str,
        default=None,
        help="Optional checkpoint path for resuming training.",
    )

    args = parser.parse_args()

    main(args)